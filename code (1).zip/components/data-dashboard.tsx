"use client"

import { SmartDashboard } from "./smart-dashboard"

export function DataDashboard() {
  return <SmartDashboard />
}
